// Problem 1
// Print "Masai School" in the console followed by "A Transformation in Education" in next line

console.log("Masai School");
console.log("A Transformation in Education");